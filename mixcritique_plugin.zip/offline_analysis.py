"""
Offline mix analysis script for MixCritique
==========================================

This Python script replicates the core analysis performed by the MixCritique
audio plug‑in.  It reads a stereo WAV file, computes basic frequency
balance, crest factor and stereo metrics, and prints constructive
feedback to the console.  Use this as a quick way to prototype the
feedback without building the plug‑in.

Usage:

    python offline_analysis.py path/to/your_mix.wav

Requirements:
    - numpy
    - scipy (for wav file reading)

"""

import sys
import numpy as np
from scipy.io import wavfile


def compute_rms_and_peak(signal: np.ndarray) -> (float, float):
    """Compute the RMS and peak amplitude of a mono signal."""
    if signal.size == 0:
        return 0.0, 0.0
    rms = np.sqrt(np.mean(signal ** 2))
    peak = np.max(np.abs(signal))
    return float(rms), float(peak)


def compute_crest_factor_db(rms: float, peak: float) -> float:
    """Compute crest factor in decibels."""
    if rms <= 0 or peak <= 0:
        return 0.0
    return 20.0 * np.log10(peak / rms)


def compute_frequency_bands(signal: np.ndarray, sample_rate: int) -> (float, float, float):
    """Compute the energy in low (<250 Hz), mid (250–4000 Hz) and high (>4 kHz) bands."""
    # zero‑pad to next power of two
    n = signal.size
    fft_size = 1 << (int(np.ceil(np.log2(n))))
    padded = np.zeros(fft_size, dtype=float)
    padded[:n] = signal
    # apply Hann window
    window = np.hanning(fft_size)
    windowed = padded * window
    # compute magnitude spectrum
    spectrum = np.fft.rfft(windowed)
    freqs = np.fft.rfftfreq(fft_size, 1.0 / sample_rate)
    magnitudes = np.abs(spectrum)
    energies = magnitudes ** 2
    low_energy = np.sum(energies[freqs < 250])
    mid_energy = np.sum(energies[(freqs >= 250) & (freqs < 4000)])
    high_energy = np.sum(energies[freqs >= 4000])
    return float(low_energy), float(mid_energy), float(high_energy)


def compute_stereo_metrics(left: np.ndarray, right: np.ndarray) -> (float, float):
    """Compute stereo width ratio and correlation coefficient."""
    mid = 0.5 * (left + right)
    side = 0.5 * (left - right)
    mid_energy = np.sum(mid ** 2)
    side_energy = np.sum(side ** 2)
    width_ratio = side_energy / (mid_energy + side_energy + 1e-30)
    # correlation
    sum_lr = np.sum(left * right)
    sum_ll = np.sum(left ** 2)
    sum_rr = np.sum(right ** 2)
    if sum_ll > 0 and sum_rr > 0:
        correlation = sum_lr / np.sqrt(sum_ll * sum_rr)
    else:
        correlation = 1.0
    return float(width_ratio), float(correlation)


def generate_advice(low_ratio: float, high_ratio: float,
                    crest_factor_db: float, width_ratio: float,
                    correlation: float) -> str:
    """Generate a feedback string based on the computed metrics."""
    lines = []
    if low_ratio > 0.45:
        lines.append(f"Low end appears dominant ({low_ratio*100:.1f}% of energy). Consider high‑pass filtering or reducing sub‑bass to tighten up your mix.")
    if high_ratio > 0.45:
        lines.append(f"High frequencies are very prominent ({high_ratio*100:.1f}% of energy). Trimming the treble can reduce harshness or sibilance.")
    if low_ratio < 0.15:
        lines.append("Low end seems underrepresented. You might need more bass instruments or a gentle low‑frequency boost.")
    if high_ratio < 0.10:
        lines.append("High end seems lacking. A subtle high‑shelf boost could add air and clarity.")
    if crest_factor_db < 6.0:
        lines.append(f"Crest factor is very low ({crest_factor_db:.1f} dB), indicating heavy compression. Easing off compression or limiting could restore dynamics.")
    elif crest_factor_db > 20.0:
        lines.append(f"Crest factor is high ({crest_factor_db:.1f} dB). A bit of compression might help control peaks and glue the mix together.")
    else:
        lines.append(f"Crest factor is within a healthy range ({crest_factor_db:.1f} dB). Dynamics look good.")
    if width_ratio < 0.10:
        lines.append("Stereo width is narrow. Mid/side processing could help widen the image.")
    elif width_ratio > 0.50:
        lines.append("Stereo width is very wide. Check for phase issues and ensure mono compatibility.")
    else:
        lines.append("Stereo width is balanced.")
    if correlation < 0.0:
        lines.append("Phase correlation is negative. The left and right channels may be out of phase; this can cause stereo cancellation.")
    elif correlation < 0.3:
        lines.append("Phase correlation is low. While a wide image can be exciting, watch out for mono compatibility issues.")
    elif correlation > 0.95:
        lines.append("Phase correlation is very high. The mix may be overly mono; consider adding stereo elements.")
    return "\n".join(lines) if lines else "Mix looks balanced. Keep trusting your ears!"


def main(path: str) -> None:
    sr, data = wavfile.read(path)
    # Normalise integer PCM to float in [-1,1]
    if data.dtype == np.int16:
        data = data.astype(np.float32) / 32768.0
    elif data.dtype == np.int32:
        data = data.astype(np.float32) / 2147483648.0
    elif data.dtype == np.uint8:
        data = (data.astype(np.float32) - 128.0) / 128.0
    else:
        data = data.astype(np.float32)
    if data.ndim == 1:
        # mono file: duplicate channel
        left = right = data
    else:
        left = data[:, 0]
        right = data[:, 1]
    # compute mono for dynamics and frequency
    mono = 0.5 * (left + right)
    rms, peak = compute_rms_and_peak(mono)
    crest = compute_crest_factor_db(rms, peak)
    low, mid, high = compute_frequency_bands(mono, sr)
    total = low + mid + high + 1e-30
    low_ratio = low / total
    high_ratio = high / total
    width_ratio, corr = compute_stereo_metrics(left, right)
    print("Sample rate:", sr, "Hz")
    print(f"Crest factor: {crest:.2f} dB")
    print(f"Low energy ratio: {low_ratio*100:.1f}%  High energy ratio: {high_ratio*100:.1f}%")
    print(f"Stereo width ratio: {width_ratio:.2f}  Correlation: {corr:.2f}")
    print("\nFeedback:\n")
    print(generate_advice(low_ratio, high_ratio, crest, width_ratio, corr))


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Usage: python offline_analysis.py path/to/audio.wav")
        sys.exit(1)
    main(sys.argv[1])