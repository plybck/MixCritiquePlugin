/*
    This file contains the processor logic for the MixCritique plug‑in.

    The processor analyses incoming audio in real time and derives
    several simple metrics: frequency balance, crest factor (dynamic
    range) and stereo width.  From these metrics it generates a brief
    textual report that encourages the user to adjust EQ, compression
    or stereo imaging.  See README.md for more details.
*/

#pragma once

#include <JuceHeader.h>
#include <string>

//==============================================================================
class MixCritiqueAudioProcessor  : public juce::AudioProcessor
{
public:
    //==============================================================================
    MixCritiqueAudioProcessor();
    ~MixCritiqueAudioProcessor() override;

    //==============================================================================
    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

   #ifndef JucePlugin_PreferredChannelConfigurations
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
   #endif

    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    //==============================================================================
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    //==============================================================================
    const juce::String getName() const override;

    bool acceptsMidi() const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;

    //==============================================================================
    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int index, const juce::String& newName) override;

    //==============================================================================
    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    /** Returns the current advice text.  The editor polls this method to
        update its display. */
    std::string getAdvice() const;

private:
    /** Compute RMS and peak levels for the provided mono signal. */
    void computeRmsAndPeak (const float* data, int numSamples, double& rms, double& peak) const;

    /** Compute the crest factor in dB from RMS and peak values. */
    double computeCrestFactorDb (double rms, double peak) const;

    /** Analyse the frequency content of a mono signal and fill low, mid and
        high energy outputs.  Frequencies below 250 Hz contribute to low,
        250–4000 Hz to mid and above 4000 Hz to high. */
    void computeFrequencyBands (const float* data, int numSamples,
                                double& lowEnergy, double& midEnergy, double& highEnergy);

    /** Compute the ratio of side energy to total energy and the correlation
        between left and right channels. */
    void computeStereoMetrics (const float* left, const float* right, int numSamples,
                               double& widthRatio, double& correlation) const;

    /** Generate a human readable advice string from the computed metrics. */
    std::string generateAdvice (double lowRatio, double highRatio,
                                double crestFactorDb, double widthRatio,
                                double correlation) const;

    // Analysis buffers and helpers
    std::unique_ptr<juce::dsp::FFT> fft;
    std::unique_ptr<juce::dsp::WindowingFunction<float>> window;
    int fftOrder = 11;        // 2^11 = 2048‑point FFT
    int fftSize  = 1 << fftOrder;
    std::vector<float> fftData;

    double currentSampleRate = 44100.0;

    // Advice string updated every call to processBlock
    std::string adviceText;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MixCritiqueAudioProcessor)
};
