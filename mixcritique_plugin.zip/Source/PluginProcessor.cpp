#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>

//==============================================================================
MixCritiqueAudioProcessor::MixCritiqueAudioProcessor()
    : AudioProcessor (BusesProperties().withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                                      .withOutput ("Output", juce::AudioChannelSet::stereo(), true))
{
    // Allocate FFT and windowing objects
    fft  = std::make_unique<juce::dsp::FFT>(fftOrder);
    window = std::make_unique<juce::dsp::WindowingFunction<float>>(fftSize, juce::dsp::WindowingFunction<float>::hann, true);
    fftData.resize(2 * fftSize, 0.0f);
}

MixCritiqueAudioProcessor::~MixCritiqueAudioProcessor()
{
}

//==============================================================================
const juce::String MixCritiqueAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool MixCritiqueAudioProcessor::acceptsMidi() const
{
   return false;
}

bool MixCritiqueAudioProcessor::producesMidi() const
{
   return false;
}

bool MixCritiqueAudioProcessor::isMidiEffect() const
{
   return false;
}

double MixCritiqueAudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int MixCritiqueAudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
                // so this should be at least 1, even if you're not really implementing programs.
}

int MixCritiqueAudioProcessor::getCurrentProgram()
{
    return 0;
}

void MixCritiqueAudioProcessor::setCurrentProgram (int index)
{
    juce::ignoreUnused (index);
}

const juce::String MixCritiqueAudioProcessor::getProgramName (int index)
{
    juce::ignoreUnused (index);
    return {};
}

void MixCritiqueAudioProcessor::changeProgramName (int index, const juce::String& newName)
{
    juce::ignoreUnused (index, newName);
}

//==============================================================================
void MixCritiqueAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    juce::ignoreUnused (samplesPerBlock);
    currentSampleRate = sampleRate;
}

void MixCritiqueAudioProcessor::releaseResources()
{
    // No resources to free
}

#ifndef JucePlugin_PreferredChannelConfigurations
bool MixCritiqueAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    // The plug‑in accepts only stereo input and stereo output.
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;
    if (layouts.getMainInputChannelSet()  != juce::AudioChannelSet::stereo())
        return false;
    return true;
}
#endif

void MixCritiqueAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ignoreUnused (midiMessages);
    juce::ScopedNoDenormals noDenormals;
    auto numSamples = buffer.getNumSamples();
    auto numChannels = buffer.getNumChannels();

    if (numChannels == 0 || numSamples == 0)
        return;

    // Compute crest factor on summed stereo (mono)
    std::vector<float> mono (numSamples, 0.0f);
    for (int n = 0; n < numSamples; ++n)
    {
        float sum = 0.0f;
        for (int ch = 0; ch < std::min (numChannels, 2); ++ch)
            sum += buffer.getReadPointer (ch)[n];
        mono[n] = sum / static_cast<float> (std::min (numChannels, 2));
    }

    double rms, peak;
    computeRmsAndPeak (mono.data(), numSamples, rms, peak);
    double crestFactorDb = computeCrestFactorDb (rms, peak);

    // Frequency band analysis
    double lowEnergy = 0.0, midEnergy = 0.0, highEnergy = 0.0;
    computeFrequencyBands (mono.data(), numSamples, lowEnergy, midEnergy, highEnergy);
    double totalEnergy = lowEnergy + midEnergy + highEnergy + 1e-12;
    double lowRatio  = lowEnergy  / totalEnergy;
    double highRatio = highEnergy / totalEnergy;

    // Stereo metrics
    double widthRatio = 0.0;
    double correlation = 0.0;
    if (numChannels >= 2)
    {
        const float* left  = buffer.getReadPointer (0);
        const float* right = buffer.getReadPointer (1);
        computeStereoMetrics (left, right, numSamples, widthRatio, correlation);
    }
    else
    {
        // Mono input: width zero, correlation one
        widthRatio = 0.0;
        correlation = 1.0;
    }

    adviceText = generateAdvice (lowRatio, highRatio, crestFactorDb, widthRatio, correlation);

    // Pass audio through unchanged
    for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
    {
        float* data = buffer.getWritePointer (ch);
        juce::ignoreUnused (data);
        // do nothing; this plugin is purely analytical
    }
}

//==============================================================================
bool MixCritiqueAudioProcessor::hasEditor() const
{
    return true;
}

juce::AudioProcessorEditor* MixCritiqueAudioProcessor::createEditor()
{
    return new MixCritiqueAudioProcessorEditor (*this);
}

//==============================================================================
void MixCritiqueAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    // The plug‑in has no persistent state; nothing to save
    juce::ignoreUnused (destData);
}

void MixCritiqueAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    juce::ignoreUnused (data, sizeInBytes);
}

std::string MixCritiqueAudioProcessor::getAdvice() const
{
    return adviceText;
}

//==============================================================================
void MixCritiqueAudioProcessor::computeRmsAndPeak (const float* data, int numSamples, double& rms, double& peak) const
{
    double sumSquares = 0.0;
    double maxAbs = 0.0;
    for (int i = 0; i < numSamples; ++i)
    {
        float sample = data[i];
        sumSquares += static_cast<double>(sample) * static_cast<double>(sample);
        double absVal = std::abs (static_cast<double> (sample));
        if (absVal > maxAbs)
            maxAbs = absVal;
    }
    rms  = numSamples > 0 ? std::sqrt (sumSquares / numSamples) : 0.0;
    peak = maxAbs;
}

double MixCritiqueAudioProcessor::computeCrestFactorDb (double rms, double peak) const
{
    if (rms <= 0.0 || peak <= 0.0)
        return 0.0;
    double cf = peak / rms;
    return 20.0 * std::log10 (cf);
}

void MixCritiqueAudioProcessor::computeFrequencyBands (const float* data, int numSamples,
                                                       double& lowEnergy, double& midEnergy, double& highEnergy)
{
    // Copy samples to FFT buffer and zero‑pad
    int copySize = std::min (numSamples, fftSize);
    std::fill (fftData.begin(), fftData.end(), 0.0f);
    if (copySize > 0)
        std::copy (data, data + copySize, fftData.begin());

    // Apply a Hann window to reduce spectral leakage
    window->multiplyWithWindowingTable (fftData.data(), fftSize);

    // Compute magnitudes
    fft->performFrequencyOnlyForwardTransform (fftData.data());

    // Sum energy in low/mid/high bins
    lowEnergy  = 0.0;
    midEnergy  = 0.0;
    highEnergy = 0.0;
    int numBins = fftSize / 2;
    for (int i = 0; i < numBins; ++i)
    {
        double freq = (currentSampleRate * static_cast<double>(i)) / static_cast<double>(fftSize);
        float magnitude = fftData[i];
        double energy = static_cast<double>(magnitude) * static_cast<double>(magnitude);
        if (freq < 250.0)
            lowEnergy  += energy;
        else if (freq < 4000.0)
            midEnergy  += energy;
        else
            highEnergy += energy;
    }
}

void MixCritiqueAudioProcessor::computeStereoMetrics (const float* left, const float* right, int numSamples,
                                                      double& widthRatio, double& correlation) const
{
    double midEnergy  = 0.0;
    double sideEnergy = 0.0;
    double sumLR = 0.0;
    double sumLL = 0.0;
    double sumRR = 0.0;

    for (int i = 0; i < numSamples; ++i)
    {
        double l = static_cast<double> (left[i]);
        double r = static_cast<double> (right[i]);
        // Mid/side decomposition
        double m = (l + r) * 0.5;
        double s = (l - r) * 0.5;
        midEnergy  += m * m;
        sideEnergy += s * s;
        // Correlation
        sumLR += l * r;
        sumLL += l * l;
        sumRR += r * r;
    }
    double denom = midEnergy + sideEnergy;
    widthRatio = denom > 1e-30 ? sideEnergy / denom : 0.0;
    // Normalise correlation
    if (sumLL > 0.0 && sumRR > 0.0)
        correlation = sumLR / std::sqrt (sumLL * sumRR);
    else
        correlation = 1.0;
}

std::string MixCritiqueAudioProcessor::generateAdvice (double lowRatio, double highRatio,
                                                       double crestFactorDb, double widthRatio,
                                                       double correlation) const
{
    std::string advice;
    // Frequency balance suggestions
    // Based on iZotope EQ guidelines: excessive low end causes muddiness; excessive highs cause harshness【314015651136600†L130-L132】.
    if (lowRatio > 0.45)
    {
        advice += "Low end appears dominant (" + juce::String (lowRatio * 100.0, 1).toStdString() + "% of energy). Consider high‑pass filtering or reducing sub‑bass to tighten up your mix【314015651136600†L130-L132】.\n";
    }
    if (highRatio > 0.45)
    {
        advice += "High frequencies are very prominent (" + juce::String (highRatio * 100.0, 1).toStdString() + "% of energy). Trimming the treble can reduce harshness or sibilance【314015651136600†L130-L132】.\n";
    }
    if (lowRatio < 0.15)
    {
        advice += "Low end seems underrepresented. You might need more bass instruments or a gentle low‑frequency boost.\n";
    }
    if (highRatio < 0.10)
    {
        advice += "High end seems lacking. A subtle high‑shelf boost could add air and clarity.\n";
    }

    // Crest factor suggestions based on loudness war research【470209906585513†L152-L160】.
    if (crestFactorDb < 6.0)
    {
        advice += "Crest factor is very low (" + juce::String (crestFactorDb, 1).toStdString() + " dB), indicating heavy compression. Easing off compression or limiting could restore dynamics【470209906585513†L152-L160】.\n";
    }
    else if (crestFactorDb > 20.0)
    {
        advice += "Crest factor is high (" + juce::String (crestFactorDb, 1).toStdString() + " dB). A bit of compression might help control peaks and glue the mix together.\n";
    }
    else
    {
        advice += "Crest factor is within a healthy range (" + juce::String (crestFactorDb, 1).toStdString() + " dB). Dynamics look good.\n";
    }

    // Stereo width suggestions using mid/side definitions【953007310788664†L56-L59】.
    if (widthRatio < 0.10)
    {
        advice += "Stereo width is narrow. Mid/side processing could help widen the image【953007310788664†L56-L59】.\n";
    }
    else if (widthRatio > 0.50)
    {
        advice += "Stereo width is very wide. Check for phase issues and ensure mono compatibility.\n";
    }
    else
    {
        advice += "Stereo width is balanced.\n";
    }

    if (correlation < 0.0)
    {
        advice += "Phase correlation is negative. The left and right channels may be out of phase; this can cause stereo cancellation.\n";
    }
    else if (correlation < 0.3)
    {
        advice += "Phase correlation is low. While a wide image can be exciting, watch out for mono compatibility issues.\n";
    }
    else if (correlation > 0.95)
    {
        advice += "Phase correlation is very high. The mix may be overly mono; consider adding stereo elements.\n";
    }

    if (advice.empty())
        advice = "Mix looks balanced. Keep trusting your ears!";

    return advice;
}
