#include "PluginEditor.h"
#include "PluginProcessor.h"

//==============================================================================
MixCritiqueAudioProcessorEditor::MixCritiqueAudioProcessorEditor (MixCritiqueAudioProcessor& p)
    : AudioProcessorEditor (&p), processorRef (p)
{
    // Configure the advice display
    adviceDisplay.setMultiLine (true);
    adviceDisplay.setReadOnly (true);
    adviceDisplay.setScrollbarsShown (true);
    adviceDisplay.setColour (juce::TextEditor::backgroundColourId, juce::Colours::black);
    adviceDisplay.setColour (juce::TextEditor::textColourId, juce::Colours::white);
    adviceDisplay.setColour (juce::TextEditor::outlineColourId, juce::Colours::grey);
    adviceDisplay.setFont (juce::Font (14.0f));
    addAndMakeVisible (adviceDisplay);

    // Set editor size
    setSize (480, 220);
    startTimerHz (2); // update twice per second
}

MixCritiqueAudioProcessorEditor::~MixCritiqueAudioProcessorEditor()
{
    stopTimer();
}

//==============================================================================
void MixCritiqueAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colours::black);
    g.setColour (juce::Colours::white);
    g.setFont (juce::Font (18.0f, juce::Font::bold));
    g.drawFittedText ("MixCritique", 0, 0, getWidth(), 30, juce::Justification::centred, 1);
    g.setFont (juce::Font (12.0f));
    g.drawFittedText ("Real‑time mix analysis", 0, 30, getWidth(), 20, juce::Justification::centred, 1);
}

void MixCritiqueAudioProcessorEditor::resized()
{
    auto bounds = getLocalBounds();
    bounds.removeFromTop (50);
    adviceDisplay.setBounds (bounds.reduced (10));
}

void MixCritiqueAudioProcessorEditor::timerCallback()
{
    adviceDisplay.setText (processorRef.getAdvice(), juce::dontSendNotification);
}
