# MixCritique Plug‑in

MixCritique is a proof‑of‑concept VST3 audio plug‑in that critiques a stereo
mix in real time and offers constructive feedback.  The goal of this plug‑in
is to give producers a quick sanity check on the overall tonal balance,
dynamic behaviour and stereo image of their mixes.  It analyses incoming
audio blocks, computes a handful of simple descriptors and suggests
improvements based on established audio engineering guidelines.  The
implementation deliberately keeps the signal processing light weight so it
runs comfortably inside a digital audio workstation.

## Features

* **Frequency balance analysis** – Incoming audio is transformed into the
  frequency domain using a Fast Fourier Transform.  The plug‑in sums the
  energy in three broad bands: low (<250 Hz), mid (250–4 kHz) and high
  (>4 kHz).  If the low band dominates the spectrum it warns that the mix
  may be *muddy*; likewise if the high band dominates it warns of possible
  *harshness*.  These suggestions are based on iZotope’s EQ guidelines that
  recommend removing excessive low end to tighten up a mix and trimming the
  treble to reduce harshness or sibilance【314015651136600†L130-L132】.

* **Dynamic range meter** – For every audio block the plug‑in computes the
  RMS (root‑mean‑square) level and the peak level and derives the
  **crest factor** (peak level minus RMS level in dB).  The crest factor
  describes how much transient information remains in the signal: more
  compression lowers the crest factor.  A crest factor below about 6 dB
  triggers a suggestion to ease off the compression; values above about
  20 dB are flagged as potentially lacking control.  The concept of crest
  factor as a measure of dynamic behaviour comes from sound‑on‑sound’s
  discussion of the loudness war【470209906585513†L152-L160】.

* **Stereo width and correlation** – The plug‑in converts the stereo
  signal to **mid** and **side** components, where the mid signal is
  (L+R)/2 and the side is (L−R)/2【953007310788664†L56-L59】.  It compares
  their energies to estimate how wide the mix is.  If there is very little
  side energy the mix is effectively mono and the plug‑in suggests
  widening the stereo field.  Excessive side energy or negative
  correlation (left/right channels moving in opposite directions) warns
  about possible phase issues.

* **Readable feedback** – The main window displays a short report that
  updates every half second.  The text is deliberately concise and
  references the relevant mixing principles along with a threshold
  explanation.

## Building the plug‑in

This repository contains only the source code for the plug‑in.  It
leverages the JUCE framework (https://juce.com/) and uses CMake as its
build system.  To build the plug‑in you need a copy of JUCE available on
your machine.  The minimum suggested JUCE version is 6.1.  JUCE is not
included in this repository; see the JUCE tutorials on setting up your
environment【892023507805079†L47-L59】.

1. Install JUCE and ensure that CMake can locate its modules.  The
   simplest way is to add the JUCE directory to your `CMAKE_PREFIX_PATH`.
2. From the command line run:

   ```sh
   mkdir build
   cd build
   cmake -B . -S .. -DJUCE_ENABLE_WEB_BROWSER=OFF -DJUCE_BUILD_EXAMPLES=OFF
   cmake --build . --config Release
   ```

   The generated binary will be a VST3 plug‑in called `MixCritique.vst3`.
3. Copy the resulting VST3 bundle to your DAW’s plug‑in folder.  On
   Windows this is typically `C:\Program Files\Common Files\VST3`, and
   on macOS `~/Library/Audio/Plug‑Ins/VST3`【892023507805079†L80-L88】.

### Pro Tools (AAX) support

JUCE can also generate AAX plug‑ins for use in Pro Tools, but doing so
requires the Avid AAX SDK which is licensed separately.  If you have
access to the AAX SDK, set the `AAX_SDK_PATH` in your global JUCE
configuration and add `AAX` to the list of formats in the
`juce_add_plugin` call in `CMakeLists.txt`.

## Usage and interpretation

Insert the plug‑in on the stereo master bus of your project.  Play your
mix and observe the feedback text.  If you see warnings about muddy low
end, consider using a high‑pass filter or reducing bass heavy elements.
If the plug‑in flags excessive compression (low crest factor), lower the
thresholds of your compressors or reduce limiting.  When stereo width
warnings appear, try using mid/side EQ or panning to achieve a more
balanced image.  These guidelines are general and should not replace
critical listening; always trust your ears and musical goals.
